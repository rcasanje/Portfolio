﻿<footer class="panel-footer">
	<div class="container">
		<div class="row">
			<div class="col-sm-3">
				<p><b>Ferramentas</b></p>
				<ul type="none" style="margin-left:-40px;">
					<li><a href="Mockup.php" style="text-decoration: none;">Montagem de produtos</a></li>
				</ul>
			</div>
			<div class="col-sm-3">
				<p><b>Termos</b></p>
				<ul type="none" style="margin-left:-40px;">
					<li>Termos de Serviço</li>
					<li>Política de privacidade</li>
				</ul>
			</div>
			<div class="col-sm-3">
				<p><b>Dúvida e Suporte</b></p>
				<ul type="none" style="margin-left:-40px;">
					<li>Contato</li>
				</ul>
			</div>
			<div class="col-sm-3">
				<p><b>Compartilhe</b></p>
				<ul type="none" style="margin-left:-40px;">
					<li>Facebook</li>
					<li>Twitter</li>
					<li>Google+</li>
					<li>WhatsApp</li>
				</ul>
			</div>
			<h6>D&A Design Autoral</h6>
		</div>
	</div>
</footer>