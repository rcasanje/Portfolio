﻿<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="CSS/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="CSS/sobre.css">
<script src="Js/jquery.min.js"></script>
<script src="Js/bootstrap.min.js"></script>
<title>Sobre :: Design Autoral</title>
</head>

<body>
	<?php include("PHP/barra_de_menu.php"); ?>
	<div class="container well">
		<p>Aqui fica as informações sobre a empresa</p>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur et iaculis magna, non sagittis urna. Mauris in malesuada lorem, quis ultricies dui. Nam erat turpis, mollis eu cursus sit amet, posuere id erat. Cras ac consequat ex. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse potenti. Cras commodo tincidunt posuere. Nunc eu condimentum enim. Maecenas interdum bibendum odio. Maecenas posuere aliquam sollicitudin. Integer in blandit augue. Pellentesque pharetra, lectus at ultrices gravida, libero eros efficitur tellus, vel pretium sem urna quis eros. Integer neque dui, mattis in tellus eu, scelerisque dapibus ligula. Donec et interdum velit.</p>

		<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed mattis ipsum ut nunc malesuada bibendum. Duis dictum eget eros eget maximus. Donec laoreet malesuada cursus. Nullam id ligula in elit vestibulum vulputate at ac tortor. Vivamus ut diam sed eros accumsan tempor et vel magna. Suspendisse placerat tellus vitae dolor fringilla, et tincidunt elit ullamcorper. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin feugiat facilisis risus, a pretium arcu pulvinar at. Vestibulum sodales auctor orci vitae iaculis. Nulla ullamcorper est turpis, ut elementum ipsum laoreet non. Maecenas laoreet vehicula dignissim. Vivamus eu leo sit amet sem ultrices euismod eget at lorem. Proin mollis, neque mattis auctor dictum, tellus sapien pellentesque orci, non varius tortor urna sed metus.</p>
	</div>
	<?php include("PHP/rodape.php"); ?>
</body>
</html>